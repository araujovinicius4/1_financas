java -jar irpf.jar
